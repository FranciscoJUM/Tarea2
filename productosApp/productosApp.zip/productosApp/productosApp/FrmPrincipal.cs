﻿using Dominio.Enums;
using Infraestructura.Productos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace productosApp
{
    public partial class Form1 : Form
    {
        
        private ProductoModel productosmodel;

      
        public Form1()
        {
            productosmodel = new ProductoModel();
            InitializeComponent();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Form2 a = new Form2();
            a.ShowDialog();
        }

        private void FlowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbunidaddemedida.Items.AddRange(Enum.GetValues(typeof(UnidadDeMedid)).Cast<object>().ToArray());
        }
    }
}
