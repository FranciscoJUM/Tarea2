﻿using Dominio.Enums;
using Infraestructura.Productos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace productosApp
{

    public partial class Form2 : Form
    {

        private ProductoModel pModel { get; set; }
        public Form2()
        {
            InitializeComponent();
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Cb.Items.AddRange(Enum.GetValues(typeof(UnidadDeMedid)).Cast<object>().ToArray());
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btmAceptar_Click(object sender, EventArgs e)
        {

        }
    }
    }

