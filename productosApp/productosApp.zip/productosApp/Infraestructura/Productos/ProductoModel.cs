﻿using Dominio.Emptties;
using Dominio.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;


namespace Infraestructura.Productos
{
   public class ProductoModel
    {
        private Producto[] productos;
        public void Add(Producto p)
        {
            Add(p, ref productos);
        }
        public int Update(Producto a)
        {
            int index = GetIndexbycodigo(a);
            if (index < 0)
            {
                throw new ArgumentException(" no se encontro el producto");
            }
            else
            {
                productos[index] = a;
                return -1;
            }
        }
        public bool Delete(Producto c)
        {
            int index = GetIndexbycodigo(c);
            if (index < 0)
            {
                throw new ArgumentException(" no se encontro el producto");
            }
            if(index != productos.Length)
                {
                productos[index] = productos[productos.Length - 1];
            }
               
            Producto[] tmp = new Producto[productos.Length - 1];
            Array.Copy(productos, tmp, tmp.Length);
            return true;
        }
        /* imcompleto public void GetProductoById()
        { }*/
        public Producto[] GetAll()
        {

            return productos;
        }
        public Producto[] BuscarByUnudadmedida(UnidadDeMedid un){

            Producto[] tmp = null;
            foreach (Producto p in productos){
                if (p.Unidaddemedidas == un)
                {
                    Add(p, ref tmp);
                
                }
                
            }
            return tmp;
        }
        public Producto[] BuscarPorFechadeVencimineto(DateTime t)
        {
            Producto[] tmp = null;
            if (productos == null) 
            {
                return tmp;
            }
            foreach (Producto p in productos)
            {
                if (p.Caducidad.CompareTo(t) <= 0)
                {
                    Add(p , ref tmp);
                }

            }
            return tmp;






        }
        public Producto[] ProductoByRango(decimal a, decimal b)
        {
            Producto[] tmp = null;
            if (productos == null)
            {
                return tmp;
            }
            foreach (Producto p in productos)
            {
                if (p.Precio >= a && p.Precio <= b)
                {
                    Add(p, ref tmp);
                }

            }
            return tmp;

        }
        public string GetProductoJson()
        {
           
            return JsonConvert.SerializeObject(productos);
        }
        public Producto[] ProductoByPrecio()
        {
            Array.Sort(productos, new Producto.ProductoOrderbyprecio());
            return productos;


        }
        public int GetlastPruduct()
            {

            return productos == null ? 0 : productos[productos.Length - 1].ID;
        }

      
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        // metodos privados
        private void Add(Producto e, ref Producto[] pds)
        {
            if (pds == null)
            {
                pds = new Producto[1];
                pds[pds.Length - 1] = e;
                return;
            }

            Producto[] tmp = new Producto[pds.Length + 1];
            Array.Copy(pds, tmp,pds.Length);

        }
    private int GetIndexbycodigo(Producto p)
        {
            int index = int.MinValue;

            if (p == null)
            {
                throw new ArgumentException(" no puede ser null");
            }
            if (productos == null)
            {
                return index;
            }
            int i = 0;
            foreach (Producto s in productos)
            {
                if( s.ID == p.ID)
                {
                    index = i;
                    break;
                    
                }
                i++;
            }
            return index;



                }
     


        
    }
}
