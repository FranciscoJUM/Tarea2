﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio.Enums
{
public enum UnidadDeMedid
    {
        unidades,
        Litros,
        Mililitros,
        Kilogramos,
        Gramos,
        Libras
    }
}
